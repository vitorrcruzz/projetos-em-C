#include <stdio.h>

int main()
{
    float C, F;
    
    printf("Digite a temperatura em Célsius (°C): ");
    scanf("%f",&C);
    
    F = (9 * C + 160) / 5;
    
    printf("Temperatura em Célsius (°C): %.0f°C \n", C);
    printf("Temperatura em Fahrenheit (°F): %.2f°F ", F );

    return 0;
}

