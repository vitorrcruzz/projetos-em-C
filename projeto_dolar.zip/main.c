#include <stdio.h>

int main()
{
    float Cota_dolar, valor_dolar, valor_real;
    
    printf("Informe a cotação do Dólar: ");
    scanf("%f", &Cota_dolar);
    
    printf("Informe a quantidade de dólares: ");
    scanf("%f", &valor_dolar);
    
    valor_real = Cota_dolar * valor_dolar;
    
    printf("O valor em reais é: R$%.2f\n", valor_real);

    return 0;
}
