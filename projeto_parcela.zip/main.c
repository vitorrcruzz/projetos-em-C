#include <stdio.h>

int main()
{
    float VP, VC;
    
    printf("Digite o valor da compra: ");
    scanf("%f", &VC);
    
    VP = VC / 10;
    
    printf("Valor da Compra: R$%.2f \n",VC);
    
    printf("Valor parcelado em 10x: R$%.2f",VP);

    return 0;
}

